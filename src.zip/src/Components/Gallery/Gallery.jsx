import React from 'react'
function Gallery() {
    return (
        <div>
            Gallery
        </div>
    )
}

export default Gallery
