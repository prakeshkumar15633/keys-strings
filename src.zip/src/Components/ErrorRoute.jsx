import React from 'react'

function ErrorRoute() {
    return (
        <div>
            ErrorRoute
        </div>
    )
}

export default ErrorRoute