import React from 'react'

function AboutUs() {
    return (
        <div>
            Aboutus
        </div>
    )
}

export default AboutUs
