import React from 'react'
import './Footer.css'

function Footer() {
    return (
        <div className='text-center p-2 myfooter text-primary' style={{backgroundColor:'black',fontSize:'1.3rem'}}>
            Footer
        </div>
    )
}

export default Footer
