import Demo from './Components/Demo';
import './App.css';

function App() {
    return (
        <div className="App">
            <Demo/>
        </div>
    );
}

export default App;
